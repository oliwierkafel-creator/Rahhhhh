import express from 'express';
import {createServer} from 'node:http';
import {Server} from 'socket.io';
import {randomInt,randomUUID} from 'node:crypto';
import {DatabaseSync} from 'node:sqlite';
import {mkdirSync} from 'node:fs';
mkdirSync('data',{recursive:true});
const db=new DatabaseSync('data/rysownia.sqlite');
db.exec('CREATE TABLE IF NOT EXISTS rooms (code TEXT PRIMARY KEY, payload TEXT NOT NULL, updated INTEGER NOT NULL)');
const app=express(),server=createServer(app),io=new Server(server,{maxHttpBufferSize:1e5});app.use(express.static('public'));
const rooms=new Map();
function persist(r){db.prepare("INSERT INTO rooms(code,payload,updated) VALUES(?,?,?) ON CONFLICT(code) DO UPDATE SET payload=excluded.payload,updated=excluded.updated").run(r.code,JSON.stringify({...r,timer:null}),Date.now());}
for(const row of db.prepare("SELECT payload FROM rooms WHERE updated > ?").all(Date.now()-86400000)){try{const r=JSON.parse(row.payload);rooms.set(r.code,r);if(r.phase==='drawing'){r.timer=setTimeout(()=>end(r),Math.max(1,r.deadline-Date.now()));}else if(r.phase==='order'||r.phase==='result'){r.timer=setTimeout(()=>r.phase==='order'?next(r):(r.turn++,next(r)),3000);}}catch{}}const words=['kot','rower','zamek','samolot','pizza','drzewo','okulary','rakieta','parasol','żaba','latarnia','statek','pociąg','bałwan','lodówka','żółw','kaktus','motyl','wulkan','telewizor','pies','księżyc','gitara','most','arbuz','zegar','krzesło','krowa','dom','telefon','koszyk','słoń','dinozaur','kwiat','tramwaj','kapelusz','komputer','ślimak','latarka','plecak','królik','jabłko','samochód','robot','balon','namiot','korona','but','książka','fontanna'];
const norm=s=>String(s).toLocaleLowerCase('pl').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/ł/g,'l').replace(/[^a-z0-9]/g,'');
const publicState=r=>({code:r.code,host:r.host,phase:r.phase,players:r.players.map(p=>({id:p.id,name:p.name,score:p.score,connected:p.connected,guessed:p.guessed})),rounds:r.rounds,round:r.round,turn:r.turn,order:r.order,drawer:r.drawer,deadline:r.deadline,strokes:r.strokes,events:r.events.slice(-4),reveal:r.reveal||null});
function emit(r){persist(r);io.to(r.code).emit('state',publicState(r));}
function clear(r){if(r.timer)clearTimeout(r.timer);r.timer=null;}
function end(r){if(r.phase!=='drawing')return;clear(r);r.phase='result';r.reveal=r.word;const drawer=r.players.find(p=>p.id===r.drawer);if(drawer)drawer.score+=r.players.filter(p=>p.id!==r.drawer&&p.guessed).length*25;emit(r);r.timer=setTimeout(()=>{if(r.phase==='result'){r.turn++;next(r);}},5500);}
function next(r){clear(r);if(r.turn>=r.order.length*r.rounds){r.phase='finished';emit(r);return;}r.round=Math.floor(r.turn/r.order.length)+1;r.drawer=r.order[r.turn%r.order.length];r.phase='choose';r.reveal=null;r.word=null;r.strokes=[];r.events=[];r.players.forEach(p=>p.guessed=false);r.choices=[...words].sort(()=>Math.random()-.5).slice(0,5);emit(r);io.to(r.drawer).emit('choices',r.choices);}
function playerRoom(s){return [...rooms.values()].find(r=>r.players.some(p=>p.id===s.data.pid));}
function valid(s,r){return r&&r.players.some(p=>p.id===s.data.pid);}
io.on('connection',s=>{
s.on('watch',({code},cb)=>{const r=rooms.get(String(code));if(!r)return cb?.({error:'Nie znaleziono pokoju'});s.join(r.code);s.data.watch=r.code;cb?.({ok:true});s.emit('state',publicState(r));});
s.on('create',({name},cb)=>{let code;do{code=String(randomInt(100000,1000000));}while(rooms.has(code));const pid=randomUUID(),p={id:pid,name:String(name||'Host').trim().slice(0,22),score:0,connected:true,guessed:false};const r={code,host:pid,players:[p],phase:'lobby',rounds:3,round:0,turn:0,order:[],strokes:[],events:[]};rooms.set(code,r);s.data.pid=pid;s.join(code);cb?.({ok:true,code,pid});emit(r);});
s.on('join',({code,name,pid},cb)=>{const r=rooms.get(String(code));if(!r)return cb?.({error:'Nie znaleziono pokoju'});let p=pid&&r.players.find(x=>x.id===pid);if(!p){if(r.phase!=='lobby'||r.players.length>=6)return cb?.({error:'Gra trwa lub pokój jest pełny'});p={id:randomUUID(),name:String(name||'Gracz').trim().slice(0,22),score:0,connected:true,guessed:false};r.players.push(p);}p.connected=true;s.data.pid=p.id;s.join(r.code);cb?.({ok:true,code:r.code,pid:p.id});emit(r);if(r.phase==='choose'&&r.drawer===p.id)s.emit('choices',r.choices);if(r.phase==='drawing'&&r.drawer===p.id)s.emit('drawerWord',r.word);});
s.on('rounds',n=>{const r=playerRoom(s);if(valid(s,r)&&r.host===s.data.pid&&r.phase==='lobby'){r.rounds=Math.max(1,Math.min(10,Number(n)||3));emit(r);}});
s.on('start',()=>{const r=playerRoom(s);if(!valid(s,r)||r.host!==s.data.pid||r.phase!=='lobby'||r.players.length<3)return;r.order=r.players.map(p=>p.id);for(let i=r.order.length-1;i>0;i--){const j=randomInt(i+1);[r.order[i],r.order[j]]=[r.order[j],r.order[i]];}r.turn=0;r.phase='order';emit(r);r.timer=setTimeout(()=>next(r),5500);});
s.on('choose',word=>{const r=playerRoom(s);if(!valid(s,r)||r.phase!=='choose'||r.drawer!==s.data.pid||!r.choices.includes(word))return;r.word=word;s.emit('drawerWord',word);r.phase='drawing';r.deadline=Date.now()+90000;emit(r);r.timer=setTimeout(()=>end(r),90000);});
s.on('stroke',stroke=>{const r=playerRoom(s);if(!valid(s,r)||r.phase!=='drawing'||r.drawer!==s.data.pid)return;if(!stroke||!['start','move','end'].includes(stroke.t)||!Number.isFinite(stroke.x)||!Number.isFinite(stroke.y))return;const data={t:stroke.t,x:Math.max(0,Math.min(1,stroke.x)),y:Math.max(0,Math.min(1,stroke.y)),color:/^#[0-9a-f]{6}$/i.test(stroke.color)?stroke.color:'#202938',size:Math.max(1,Math.min(28,Number(stroke.size)||5))};r.strokes.push(data);if(r.strokes.length>15000)r.strokes.shift();s.to(r.code).emit('stroke',data);if(r.strokes.length%60===0)persist(r);});
s.on('guess',answer=>{const r=playerRoom(s);if(!valid(s,r)||r.phase!=='drawing'||r.drawer===s.data.pid)return;const p=r.players.find(p=>p.id===s.data.pid);if(p.guessed)return;if(norm(answer)!==norm(r.word)){s.emit('guessResult',false);return;}p.guessed=true;const rank=r.players.filter(p=>p.guessed&&p.id!==r.drawer).length;const base=(r.players.length-rank)*50;const bonus=Math.round(50*Math.max(0,r.deadline-Date.now())/90000);p.score+=base+bonus;r.events.push(`${p.name} odgadł(a) rysunek! +${base+bonus}`);s.emit('guessResult',true);emit(r);if(r.players.filter(p=>p.id!==r.drawer&&p.connected).every(p=>p.guessed))end(r);});
s.on('next',()=>{const r=playerRoom(s);if(valid(s,r)&&r.phase==='result'&&r.host===s.data.pid){r.turn++;next(r);}});
s.on('disconnect',()=>{const r=playerRoom(s);if(!r)return;const p=r.players.find(p=>p.id===s.data.pid);if(p){p.connected=false;emit(r);} });
});
setInterval(()=>{for(const [code,r] of rooms){if(r.players.every(p=>!p.connected)){clear(r);rooms.delete(code);db.prepare('DELETE FROM rooms WHERE code=?').run(code);}}},3600000);
server.listen(process.env.PORT||3000,()=>console.log('Rysownia ready'));
